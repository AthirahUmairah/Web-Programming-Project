<?php

include_once 'database.php';
if(empty($_SESSION)) // if the session not yet started 
   session_start();

if(!isset($_SESSION['useremail'])) { //if not yet logged in
   header("Location: login.php");// send to login page
   exit;
} 

?>

