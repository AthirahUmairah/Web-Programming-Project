<?php
 
$servername = "lrgs.ftsm.ukm.my";
$username = "a164933";
$password = "littleblacksheep";
$dbname = "a164933";
 
?>